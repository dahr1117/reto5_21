public class Arranque 
{
    public static void main(String[] args) 
    {
        //Interfaz i = new Interfaz();
        //i.presentarMenuPrincipal();
        
        GUI g = new GUI();
    }
}