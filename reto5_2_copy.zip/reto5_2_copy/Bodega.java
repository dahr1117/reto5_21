import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;

public class Bodega 
{
    private List<Producto> listaProductos;
    
    public Bodega()
    {
        this.listaProductos = new ArrayList<Producto>();
    }
    
    public List<Producto> getListaProductos()
    {
        this.listaProductos.clear();
        BaseDatos bd = new BaseDatos();
        bd.crearConexion();
        //ResultSet rs = bd.consultar("SELECT codigo, nombre, marca, presentacion, tipo, precio, cantidad "+
        //                            "FROM TProducto");
        ResultSet rs = bd.consultar("SELECT Id, Nombre, Temperatura, ValorBase, tipo, precio, cantidad "+
                                    "FROM TProductos");                            
        try
        {
            while(rs.next())
            {
                String Id = rs.getString(1);
                String Nombre = rs.getString(2);
                int Temperatura = rs.getInt(3);
                int ValorBase = rs.getInt(4);
                int Costo = rs.getInt(5);
                Producto p = new Producto(Id, Nombre, Temperatura, ValorBase, Costo);
                this.listaProductos.add(p);
            }
        }
        catch(Exception e)
        {
            return null;
        }
        bd.cerrarConexion();
        return this.listaProductos;
    }

    public void agregarProducto(Producto p) 
    {
        BaseDatos bd = new BaseDatos();
        String sql = "INSERT INTO TProducto(Id, Nombre, Temperatura, VAlorBase, Costo) "+
                     "VALUES (\""+p.getId()+"\", \""+p.getNombre()+"\", \""+p.getTemperatura()+"\", \""+p.getValorBase()+"\", \""+p.getCosto()+") ";
        bd.crearConexion();
        bd.insertar(sql);
        bd.cerrarConexion();
    }

    public ArrayList<Producto> buscarProductos(String criterio)
    {
        ArrayList<Producto> listaEncontrados = new ArrayList<Producto>();
        BaseDatos bd = new BaseDatos();
        bd.crearConexion();
        String sql = "SELECT Id, Nombre, Temperatura, ValorBase, Costo "+
                     "FROM TProductos "+
                     "WHERE Nombre LIKE \"%"+criterio+"%\" "+
                     "OR Temperatura LIKE \"%"+criterio+"%\" "+
                     "OR ValorBase LIKE \"%"+criterio+"%\" "+
                     "OR Costo LIKE \"%"+criterio+"%\" ";
        ResultSet rs = bd.consultar(sql);
        try
        {
            while(rs.next())
            {
                String Id = rs.getString(1);
                String Nombre = rs.getString(2);
                int Temperatura = rs.getInt(3);
                int ValorBase = rs.getInt(4);
                int Costo = rs.getInt(5);
                Producto p = new Producto(Id, Nombre, Temperatura, ValorBase, Costo);
                listaEncontrados.add(p);
            }
        }
        catch(Exception e)
        {
            return null;
        }
        bd.cerrarConexion();
        return listaEncontrados;
    }
    
    public Producto buscarProducto(String codigoBuscar)
    {
        Producto p = null;
        BaseDatos bd = new BaseDatos();
        bd.crearConexion();
        String sql = "SELECT Id, Nombre, Temperatura, ValorBase, Costo "+
                     "FROM TProductos "+
                     "WHERE codigo = \""+codigoBuscar+"\" ";
        ResultSet rs = bd.consultar(sql);
        try
        {
            while(rs.next())
            {
                String Id = rs.getString(1);
                String Nombre = rs.getString(2);
                int Temperatura = rs.getInt(3);
                int ValorBase = rs.getInt(4);
                int Costo = rs.getInt(5);
                p = new Producto(Id, Nombre, Temperatura, ValorBase, Costo);
            }
        }
        catch(Exception e)
        {
            return null;
        }
        bd.cerrarConexion();
        return p;
    }
    
    public void eliminarProducto(String Id) 
    {
        BaseDatos bd = new BaseDatos();
        bd.crearConexion();
        String sql = "DELETE FROM TProductos "+
                     "WHERE Id = \""+Id+"\" ";
        bd.borrar(sql);
        bd.cerrarConexion();
        
    }

    public void surtirProducto(String Id, int Temperatura, int ValorBase) 
    {
        BaseDatos bd = new BaseDatos();
        bd.crearConexion();
        String sql = "UPDATE TProductos "+
                     "SET Temperatura = "+Temperatura+", ValorBase = "+ValorBase+" "+
                     "WHERE Id = \""+Id+"\"";
        bd.actualizar(sql);
        bd.cerrarConexion();
    }

    public void disminuirCantProducto(String Id, int Temperatura) 
    {
        BaseDatos bd = new BaseDatos();
        bd.crearConexion();
        String sql = "UPDATE TProductos "+
                     "SET Temperatura = Temperatura - "+Temperatura+" "+
                     "WHERE Id = \""+Id+"\"";
        bd.actualizar(sql);
        bd.cerrarConexion();
    }
    
}






