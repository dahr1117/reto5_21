public class Producto 
{
    private String Id;
    private String Nombre;
    private int Temperatura;
    private int ValorBase;
    private int Costo;

    public Producto() 
    {
        this.Id = "";
        this.Nombre = "";
        this.Temperatura = 0;
        this.ValorBase = 0;
    }

    public Producto(String Id, String Nombre, int Temperatura, int ValorBase, int Costo) 
    {
        this.Id = Id;
        this.Nombre = Nombre;
        this.Temperatura = Temperatura;
        this.ValorBase = ValorBase;
        this.Costo = Temperatura + 1;
    }

    public void setCosto(int Costo) 
    {
        this.Costo = Costo;
    }

    public void ValorBase(int ValorBase) 
    {
        this.ValorBase = ValorBase;
    }
    
    public void Temperatura(int Temperatura) 
    {
        this.ValorBase = ValorBase;
    }

    public String getId() 
    {
        return this.Id;
    }

    public String getNombre() 
    {
        return this.Nombre;
    }

        public int getCosto() 
    {
        return this.Costo;
    }

    public int getTemperatura() 
    {
        return this.Temperatura;
    }
    
    public int getValorBase() 
    {
        return this.ValorBase;
    }

    public String toString()
    {
        return this.Id+" "+this.Nombre + " - "+this.Temperatura + "� (" + this.ValorBase + ") costo total: " + this.Costo;
    }
    
    public String toCSV()
    {
        return this.Id+";"+this.Nombre+";"+this.Temperatura+";"+this.ValorBase+";"+this.Costo;
    }
}



