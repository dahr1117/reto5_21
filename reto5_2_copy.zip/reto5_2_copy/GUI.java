import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Random;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import javax.swing.ListSelectionModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.util.List;
public class GUI extends JFrame
{
    JTextField txtCodigo, txtMarca, txtPresent, txtCant, txtPrecio, txtBuscar;
    JTextField txtNombre, txtId, txtTemp, txtValBase, txtCosto;
    JComboBox comboTipo;
    JButton btnAgregar,  btnLimpiar, btnFiltrar, btnQuitarFiltro;
    JButton btnGuardar, btnActualizar, btnEliminar, btnConsultar;
    JTable tablaProductos;
    DefaultTableModel dtm;
    
    public GUI()
    {
        iniciarComponentes();
        cargarProductos();
        implementarListeners();
    }
    
    public void iniciarComponentes()
    {
        setBounds(100, 100, 1200, 600);
        setTitle("Productos");
        setLayout(null);
        
        //Creaci�n de p�neles
        JPanel panelBanner = new JPanel();
        panelBanner.setBounds(0, 0, 1200, 80);
        panelBanner.setBackground(new Color(80, 240, 120));   
        panelBanner.setLayout(null);
        getContentPane().add(panelBanner);
        
        JPanel panelFormulario = new JPanel();
        panelFormulario.setBounds(5, 80, 400, 450);
        panelFormulario.setBorder(BorderFactory.createEtchedBorder());
        panelFormulario.setLayout(null);
        getContentPane().add(panelFormulario);
        
        JPanel panelTabla = new JPanel();
        panelTabla.setBounds(410, 80, 770, 450);
        panelTabla.setBorder(BorderFactory.createEtchedBorder());
        panelTabla.setLayout(null);
        getContentPane().add(panelTabla);
        
        //Componentes del panel del banner
        JLabel labelTitulo = new JLabel("Sistema de Inventario Farmacia");
        labelTitulo.setBounds(20, 20, 500, 60);
        labelTitulo.setFont(new Font("Arial", Font.BOLD, 28));
        labelTitulo.setForeground(Color.BLACK);
        panelBanner.add(labelTitulo);
        
        Image imagen = new ImageIcon("imgs\\logo_shop.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        JLabel labelLogo = new JLabel(new ImageIcon(imagen));
        labelLogo.setBounds(1050, 10, 84, 80);
        panelBanner.add(labelLogo);
        
        //Componentes del panel del formulario
        JLabel labelId = new JLabel("Id: ");
        labelId.setBounds(20, 50, 100, 30);
        panelFormulario.add(labelId);
        
        txtId = new JTextField();
        txtId.setBounds(120, 50, 250, 30);
        panelFormulario.add(txtId);
        
        JLabel labelNombre = new JLabel("Nombre: ");
        labelNombre.setBounds(20, 100, 100, 30);
        panelFormulario.add(labelNombre);
        
        txtNombre = new JTextField();
        txtNombre.setBounds(120, 100, 250, 30);
        panelFormulario.add(txtNombre);
        
        JLabel labelTemp = new JLabel("Temperatura: ");
        labelTemp.setBounds(20, 150, 100, 30);
        panelFormulario.add(labelTemp);
        
        txtTemp = new JTextField();
        txtTemp.setBounds(120, 150, 250, 30);
        panelFormulario.add(txtTemp);
        
        JLabel labelValBase = new JLabel("Valor Base: ");
        labelValBase.setBounds(20, 200, 100, 30);
        panelFormulario.add(labelValBase);
        
        txtValBase = new JTextField();
        txtValBase.setBounds(120, 200, 250, 30);
        panelFormulario.add(txtValBase);
        
        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(220, 250, 100, 30);   
        panelFormulario.add(btnGuardar);
        
        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(220, 300, 100, 30);   
        panelFormulario.add(btnActualizar);
        
        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(220, 350, 100, 30);   
        panelFormulario.add(btnEliminar);
        
        btnConsultar = new JButton("Consultar");
        btnConsultar.setBounds(220, 400, 100, 30);   
        panelFormulario.add(btnConsultar);
        
        //Componentes del panel de la tabla
        Object[][] datos = null;
        String[] columnas = {"Id", "Nombre", "Temperatura", "Valor Base", "Costo"};
        dtm = new DefaultTableModel(datos, columnas);
        
        JTable tablaProductos = new JTable(dtm);
        tablaProductos.setPreferredScrollableViewportSize(new Dimension(715, 290));
        tablaProductos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaProductos.setFillsViewportHeight(true);
        JScrollPane scroll = new JScrollPane(tablaProductos);
        
        JPanel contenidoTabla = new JPanel();
        contenidoTabla.setBounds(10, 10, 750, 290);
        contenidoTabla.setLayout(new GridLayout(1,0));
        contenidoTabla.add(scroll);
        panelTabla.add(contenidoTabla);
        
        setVisible(true);
    }

    public void cargarProductos()
    {
        dtm.setRowCount(0);
        Bodega bodega = new Bodega();
        List<Producto> productos = bodega.getListaProductos();
        for (Producto p : productos)
        {
            Object[] row = { p.getId(), p.getNombre(), p.getTemperatura(), p.getValorBase(), p.getCosto() };
            dtm.addRow(row);
        }
    }
    
    public void implementarListeners()
    {
        btnFiltrar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                cargarProductosFiltrados();
            }
        });
        
        btnQuitarFiltro.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                limpiarFiltro();
            }
        });
        
        btnAgregar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                agregarProducto();
            }
        });
        
        btnLimpiar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                limpiarFormulario();
            }
        });
        
        tablaProductos.getSelectionModel().addListSelectionListener(new ListSelectionListener() 
        {
            public void valueChanged(ListSelectionEvent e) 
            {
                if (tablaProductos.getSelectedRowCount() > 0)
                {
                    int row = tablaProductos.getSelectedRow();
                    String codigo = dtm.getValueAt(row, 0).toString();
                    cargarProductoEnFormulario(codigo);
                }
            }
        });
        
        btnActualizar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                actualizarProducto();
            }
        });
        
        btnEliminar.addActionListener(new ActionListener() 
        {
            public void actionPerformed(ActionEvent e) 
            {
                eliminarProducto();
            }
        });
        
        txtCant.addKeyListener(new KeyAdapter() 
        {
            public void keyTyped(KeyEvent e)
            {
                char tecla = e.getKeyChar();
                if (tecla < '0' || tecla > '9' && tecla != '\b') 
                {
                    e.consume();
                }
            }
        });
        
        txtPrecio.addKeyListener(new KeyAdapter() 
        {
            public void keyTyped(KeyEvent e)
            {
                char tecla = e.getKeyChar();
                if (tecla < '0' || tecla > '9' && tecla != '\b') 
                {
                    e.consume();
                }
            }
        });
    }
    
    public void cargarProductosFiltrados()
    {
        dtm.setRowCount(0);
        Bodega bodega = new Bodega();
        String criterio = txtBuscar.getText();
        List<Producto> productos = bodega.buscarProductos(criterio);
        for (Producto p : productos)
        {
            Object[] row = { p.getId(), p.getNombre(), p.getTemperatura(), p.getValorBase(), p.getCosto() };
            dtm.addRow(row);
        }
    }
    
    public void limpiarFiltro()
    {
        txtBuscar.setText("");
        cargarProductos();   
    }
    
    public String generarCodigoAleatorio()
    {
        Random random = new Random();
        String caracteres = "0123456789abcdefghijklmnopqrstuvwxyz";
        String codigo = "";
        for (int i=0; i<10; i++)
        {
            int index = random.nextInt(caracteres.length());
            codigo = codigo + caracteres.charAt(index);
        }
        return codigo;
    }
    
    public void agregarProducto()
    {
        if (!txtCodigo.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Debe ser un producto nuevo");
            return;
        }
        
        if (txtNombre.getText().equals("") || txtMarca.getText().equals("") || txtPresent.getText().equals("") || comboTipo.getSelectedItem().equals("") || txtCant.getText().equals("") || txtPrecio.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Debe ingresar la informaci�n completa");
            return;
        }
        String Id = generarCodigoAleatorio();
        String Nombre = txtNombre.getText();
        int Temperatura = Integer.parseInt(txtMarca.getText());
        int ValorBase = Integer.parseInt(txtCant.getText());
        int Costo = Integer.parseInt(txtPrecio.getText());
        
        Producto p = new Producto(Id, Nombre, Temperatura, ValorBase, Costo);
        Bodega bodega = new Bodega();
        bodega.agregarProducto(p);
        limpiarFormulario();
        cargarProductos();
    }
    
    public void limpiarFormulario()
    {
        txtId.setText("");
        txtNombre.setText("");
        txtTemp.setText("");
        txtValBase.setText("");
        txtCosto.setText("");
        desbloquearFormulario();
    }
    
    public void cargarProductoEnFormulario(String Id)
    {
        Bodega bodega = new Bodega();
        Producto p = bodega.buscarProducto(Id);
        txtId.setText(p.getId());
        txtNombre.setText(p.getNombre());
        txtTemp.setText(p.getTemperatura()+"");
        txtValBase.setText(p.getValorBase()+ "");
        txtCosto.setText(p.getCosto() + "");
        bloquearFormulario();
    }
    
    public void actualizarProducto()
    {
        if (txtCodigo.getText().equals("") || txtCant.getText().equals("") || txtPrecio.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Debe haber informaci�n completa para el producto a actualizar");
            return;
        }
        String codigo = txtCodigo.getText();
        int cantidad = Integer.parseInt(txtCant.getText());
        int precio = Integer.parseInt(txtPrecio.getText());
        Bodega bodega = new Bodega();
        bodega.surtirProducto(codigo, cantidad, precio);
        limpiarFormulario();
        cargarProductos();
    }
    
    public void bloquearFormulario()
    {
        txtNombre.setEditable(false);
        txtMarca.setEditable(false);
        txtPresent.setEditable(false);
        comboTipo.setEnabled(false);
    }
    
    public void desbloquearFormulario()
    {
        txtNombre.setEditable(true);
        txtMarca.setEditable(true);
        txtPresent.setEditable(true);
        comboTipo.setEnabled(true);
    }
    
    public void eliminarProducto()
    {
        if (txtCodigo.getText().equals(""))
        {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar");
            return;
        }
        int opcion = JOptionPane.showConfirmDialog(this, "Desea realmente eliminar este producto?", "Advertencia", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (opcion == JOptionPane.YES_OPTION)
        {
            Bodega bodega= new Bodega();
            bodega.eliminarProducto(txtCodigo.getText());
        }
        limpiarFormulario();
        cargarProductos();
    }
}











